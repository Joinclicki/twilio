This is a [Next.js](https://nextjs.org/) project bootstrapped with [`create-next-app`](https://github.com/vercel/next.js/tree/canary/packages/create-next-app).

## Getting Started

First, run the development server:

```bash
npm run dev
```

## Env variables
```
PUSHER_APP_ID=
PUSHER_SECRET=
NEXT_PUBLIC_PUSHER_KEY=
NEXT_PUBLIC_PUSHER_CLUSTER=

DELIVERY_STATUS_URL=https://yourdomain.com/api/delivery
RESPONSE_CALLBACK_URL=https://yourdomain.com/api/callback
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

## Core functionalities
- Add Twilio keys from different accounts and numbers
- Select a number & send mass messages from different Twilio numbers
- Show responses

## Docs
https://www.twilio.com/docs/libraries/reference/twilio-node/4.20.1/
https://ui.shadcn.com/docs
https://nextjs.org/docs

https://console.twilio.com/us1/develop/sms/try-it-out/send-an-sms/