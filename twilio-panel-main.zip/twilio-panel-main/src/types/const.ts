export const LOCAL_STORAGE_KEY = 'TP_config';
