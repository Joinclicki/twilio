interface LabelValuePair {
	value: string;
	label: string;
	_accountSid: string;
}

interface MessagingService {
	sid: string;
	friendlyName?: string;
	a2pRegistered: boolean;
}

interface PhoneNumber {
	sid: string;
	friendlyName: string;
	phoneNumber: string;
	messagingServiceSid: string;
}

interface Config {
	id: string;

	friendlyName?: string;
	accountSid: string;
	authToken: string;

	messagingServiceSid?: string;
}

interface MessageDelivery {
	messageStatus: 'valid' | 'invalid' | 'waiting' | 'queued' | 'sent' | 'failed' | 'delivered';
	to: string;
	from: string;
	errorCode?: string;
}

interface PhoneNumberResponse {
	phoneNumberSid: string;
	error?: string;
	helpUrl?: string;
}