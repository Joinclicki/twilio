import { SettingsIcon, MessageSquareMoreIcon, SendIcon, SendHorizonalIcon } from "lucide-react";
import Link from "next/link";

export function Nav() {
	return (
		<aside className="min-w-40 border-r overflow-y-auto bg-gray-200 dark:bg-gray-800">
			<div className="space-y-4 p-4">
				<Link className="flex gap-1 p-1 rounded text-gray-900 hover:bg-slate-300" href="/send">
					<SendIcon /> Send
				</Link>
				<Link className="flex gap-1 p-1 rounded text-gray-900 hover:bg-slate-300" href="/forcesend">
					<SendHorizonalIcon /> Force Send
				</Link>
				<Link className="flex gap-1 p-1 rounded text-gray-900 hover:bg-slate-300" href="/messages">
					<MessageSquareMoreIcon /> Messages
				</Link>
				<Link className="flex gap-1 p-1 rounded text-gray-900 hover:bg-slate-300" href="/config">
					<SettingsIcon /> Config
				</Link>
			</div>
		</aside>
	);
}