export default function Loading() {
	return <span className="animate-pulse rounded border-2 text-center p-1 self-start">Loading...</span>;
}
