"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  CheckIcon,
  ChevronsUpDownIcon,
  ClockIcon,
  XCircleIcon,
  MailCheckIcon,
  MailXIcon,
  CheckCircleIcon,
  Loader2Icon,
  SendIcon,
} from "lucide-react";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { toast } from "@/components/ui/use-toast";
import { Textarea } from "@/components/ui/textarea";
import { LOCAL_STORAGE_KEY } from "@/types/const";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useEffect, useState } from "react";

import Pusher from "pusher-js";
import { Input } from "@/components/ui/input";

const FormSchema = z.object({
  configId: z.string({
    required_error: "Please select a configuration.",
  }),
  message: z.string().min(1),
  phoneNumbersTo: z.string().min(1),
  mediaUrl: z.string().optional(),
});

export default function SendForm() {
  const [configs, setConfigs] = useState<Config[]>([]);
  const [statusQueue, setStatusQueue] = useState<MessageDelivery[]>([]);

  const form = useForm<z.infer<typeof FormSchema>>({
    resolver: zodResolver(FormSchema),
  });

  async function onSubmit(data: z.infer<typeof FormSchema>) {
    setStatusQueue((prev) =>
      prev.map((np) => ({ ...np, messageStatus: "waiting" } as MessageDelivery))
    );

    const config = getConfigs().find((config) => config.id === data.configId);

    const res = await fetch("/api/send", {
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        config: {
          accountSid: config?.accountSid,
          authToken: config?.authToken,
          messagingServiceSid: config?.messagingServiceSid,
        },
        body: data.message,
        phoneNumbersTo: data.phoneNumbersTo.trim().split("\n"),
        mediaUrl: data?.mediaUrl,
      }),
      method: "POST",
    });

    toast({
      title: res.ok ? "Sent." : "Failed!",
      /* description: (
				<pre className="mt-2 w-[340px] rounded-md bg-slate-950 p-4">
					<code className="text-white">{JSON.stringify(data, null, 2)}</code>
				</pre>
			), */
    });
  }

  function addNumbers(val: string) {
    const numbersStatus = val
      .trim()
      .split("\n")
      .map(
        (pn) =>
          ({
            messageStatus: /^\+[1-9]\d{1,14}$/.test(pn) ? "valid" : "invalid",
            to: pn,
          } as MessageDelivery)
      );

    setStatusQueue(numbersStatus);
  }

  function getConfigs() {
    const configs: Config[] = JSON.parse(
      localStorage?.getItem(LOCAL_STORAGE_KEY) || "[]"
    );
    return configs;
  }

  useEffect(() => {
    setConfigs(getConfigs());

    const pusher = new Pusher(process.env.NEXT_PUBLIC_PUSHER_KEY, {
      cluster: process.env.NEXT_PUBLIC_PUSHER_CLUSTER,
    });

    const channel = pusher.subscribe("main_channel");
    channel.bind("message_delivery", (data: MessageDelivery) => {
      setStatusQueue((prev) =>
        prev.map((np) => (np.to === data.to ? data : np))
      );
    });

    return () => {
      pusher.unsubscribe("main_channel");
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="w-full container">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="configId"
            render={({ field }) => (
              <FormItem className="flex flex-col">
                <FormLabel>Config</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant="outline"
                        role="combobox"
                        className={cn(
                          "w-[300px] justify-between",
                          !field.value && "text-muted-foreground"
                        )}
                      >
                        {field.value
                          ? configs.find((config) => config.id === field.value)
                              ?.friendlyName
                          : "Select a configuration"}
                        <ChevronsUpDownIcon className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-[200px] p-0">
                    <Command>
                      <CommandInput placeholder="Search configs..." />
                      <CommandEmpty>No config found.</CommandEmpty>
                      <CommandGroup>
                        {configs.map((config) => (
                          <CommandItem
                            key={config.id}
                            value={config.id}
                            onSelect={() => {
                              form.setValue("configId", config.id);
                            }}
                          >
                            <CheckIcon
                              className={cn(
                                "mr-2 h-4 w-4",
                                config.id === field.value
                                  ? "opacity-100"
                                  : "opacity-0"
                              )}
                            />
                            {config.friendlyName}
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </Command>
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="message"
            render={({ field }) => (
              <FormItem className="max-w-xl">
                <FormLabel>Message</FormLabel>
                <FormControl>
                  <Textarea placeholder="Ahoy, World!" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="phoneNumbersTo"
            render={({ field }) => (
              <FormItem className="w-[300px]">
                <FormLabel>Recipients</FormLabel>
                <FormControl>
                  <Textarea
                    onInput={(e) =>
                      addNumbers((e.target as HTMLInputElement).value)
                    }
                    placeholder={`+1XXXXXXXXXX\n+1YYYYYYYYYY\n...`}
                    {...field}
                  />
                </FormControl>
                <FormDescription>
                  Phone numbers separated by a new line.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="mediaUrl"
            render={({ field }) => (
              <FormItem className="w-[300px]">
                <FormLabel>Data Url</FormLabel>
                <FormControl>
                  <Input placeholder={`https://imageurl`} {...field} />
                </FormControl>
                <FormDescription>A Link To the url</FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          <Button className="w-32" type="submit">
            Send
          </Button>
        </form>
      </Form>

      {!!statusQueue.length && (
        <Table className="mt-5 max-w-xl">
          <TableCaption>Message status queue.</TableCaption>
          <TableHeader>
            <TableRow>
              {/* <TableHead className="">From</TableHead> */}
              <TableHead>Sender (from)</TableHead>
              <TableHead>Recipient (to)</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {statusQueue.map((msg, i) => (
              <TableRow key={`np_${i}`}>
                <TableCell className="font-mono">{msg.from}</TableCell>
                <TableCell className="font-mono">{msg.to}</TableCell>
                <TableCell className="">
                  {{
                    invalid: (
                      <p className="text-gray-400 flex gap-1">
                        <XCircleIcon /> Invalid!
                      </p>
                    ),
                    valid: (
                      <p className="flex gap-1">
                        <CheckCircleIcon /> Valid.
                      </p>
                    ),
                    waiting: (
                      <p className="flex gap-1">
                        <Loader2Icon className="animate-spin" /> Waiting for
                        response.
                      </p>
                    ),
                    queued: (
                      <p className="text-orange-400 flex gap-1">
                        <ClockIcon /> Queued.
                      </p>
                    ),
                    failed: (
                      <p className="text-red-400 flex gap-1">
                        <MailXIcon /> Failed!
                      </p>
                    ),
                    sent: (
                      <p className="text-sky-400 flex gap-1">
                        <SendIcon /> Sent!
                      </p>
                    ),
                    delivered: (
                      <p className="text-green-400 flex gap-1">
                        <MailCheckIcon /> Delivered!
                      </p>
                    ),
                  }[msg.messageStatus] || msg.messageStatus}
                </TableCell>
                {msg.errorCode ? (
                  <TableCell>
                    (Error:{" "}
                    <a
                      className="Link"
                      target="_blank"
                      href={`https://www.twilio.com/docs/api/errors/${msg.errorCode}`}
                    >
                      {msg.errorCode}
                    </a>
                    )
                  </TableCell>
                ) : (
                  ""
                )}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </div>
  );
}
