import Link from "next/link";

export default function Home() {
	return (
		<div>
			<h1>Welcome</h1>
			<p>Start with adding your <Link className="Link" href="/config">Twilio credentials.</Link></p>
			<p>Then <Link className="Link" href="/send">send</Link> a message </p>
		</div>
	);
}
