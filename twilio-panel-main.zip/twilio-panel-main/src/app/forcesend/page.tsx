'use client';

import { zodResolver } from "@hookform/resolvers/zod";
import { CheckIcon, ChevronsUpDownIcon, ClockIcon, XCircleIcon, MailCheckIcon, MailXIcon, CheckCircleIcon, Loader2Icon, SendIcon } from "lucide-react";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem } from "@/components/ui/command";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { toast } from "@/components/ui/use-toast";
import { Textarea } from "@/components/ui/textarea";
import { LOCAL_STORAGE_KEY } from "@/types/const";
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useEffect, useState } from "react";

import Pusher from "pusher-js";

const FormSchema = z.object({
	configId: z.string({
		required_error: "Please select a configuration.",
	}),
	phoneNumberFrom: z.string().min(1),
	phoneNumberTo: z.string().min(1),
	body: z.string().min(1),
});

export default function SendForm() {
	const [configs, setConfigs] = useState<Config[]>([]);

	const form = useForm<z.infer<typeof FormSchema>>({
		resolver: zodResolver(FormSchema),
	});

	async function onSubmit(data: z.infer<typeof FormSchema>) {
		const config = getConfigs().find((config) => config.id === data.configId);

		const res = await fetch('/api/forcesend', {
			headers: {
				'Content-Type': 'application/json',
			},
			body: JSON.stringify({
				config: {
					accountSid: config?.accountSid,
					authToken: config?.authToken,
					messagingServiceSid: config?.messagingServiceSid,
				},
				body: data.body,
				phoneNumberFrom: data.phoneNumberFrom,
				phoneNumberTo: data.phoneNumberTo,
			}),
			method: 'POST',
		});

		toast({
			title: res.ok ? "Sent." : "Failed!",
			/* description: (
				<pre className="mt-2 w-[340px] rounded-md bg-slate-950 p-4">
					<code className="text-white">{JSON.stringify(data, null, 2)}</code>
				</pre>
			), */
		});
	}

	function getConfigs() {
		const configs: Config[] = JSON.parse(localStorage?.getItem(LOCAL_STORAGE_KEY) || '[]');
		return configs;
	}


	useEffect(() => {
		setConfigs(getConfigs());

		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	return (
		<div className="w-full container">
			<Form {...form}>
				<form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
					<FormField
						control={form.control}
						name="configId"
						render={({ field }) => (
							<FormItem className="flex flex-col">
								<FormLabel>Config</FormLabel>
								<Popover>
									<PopoverTrigger asChild>
										<FormControl>
											<Button
												variant="outline"
												role="combobox"
												className={cn(
													"w-[300px] justify-between",
													!field.value && "text-muted-foreground"
												)}
											>
												{field.value
													? configs.find((config) => config.id === field.value)?.friendlyName
													: 'Select a configuration'}
												<ChevronsUpDownIcon className="ml-2 h-4 w-4 shrink-0 opacity-50" />
											</Button>
										</FormControl>
									</PopoverTrigger>
									<PopoverContent className="w-[200px] p-0">
										<Command>
											<CommandInput placeholder="Search configs..." />
											<CommandEmpty>No config found.</CommandEmpty>
											<CommandGroup>
												{configs.map((config) => (
													<CommandItem
														key={config.id}
														value={config.id}
														onSelect={() => {
															form.setValue("configId", config.id);
														}}
													>
														<CheckIcon
															className={cn(
																"mr-2 h-4 w-4",
																config.id === field.value
																	? "opacity-100"
																	: "opacity-0"
															)}
														/>
														{config.friendlyName}
													</CommandItem>
												))}
											</CommandGroup>
										</Command>
									</PopoverContent>
								</Popover>
								<FormMessage />
							</FormItem>
						)}
					/>
					<FormField
						control={form.control}
						name="phoneNumberFrom"
						render={({ field }) => (
							<FormItem className="w-[300px]">
								<FormLabel>Sender (From)</FormLabel>
								<FormControl>
									<Textarea placeholder="+1XXXXXXXXXX" {...field} />
								</FormControl>
								<FormMessage />
							</FormItem>
						)}
					/>
					<FormField
						control={form.control}
						name="phoneNumberTo"
						render={({ field }) => (
							<FormItem className="w-[300px]">
								<FormLabel>Recipients (To)</FormLabel>
								<FormControl>
									<Textarea placeholder="+1YYYYYYYYYY" {...field} />
								</FormControl>
								<FormMessage />
							</FormItem>
						)}
					/>
					<FormField
						control={form.control}
						name="body"
						render={({ field }) => (
							<FormItem className="max-w-xl">
								<FormLabel>Message</FormLabel>
								<FormControl>
									<Textarea placeholder="Ahoy, World!" {...field} />
								</FormControl>
								<FormMessage />
							</FormItem>
						)}
					/>
					<Button className="w-32" type="submit">Send</Button>
				</form>
			</Form>
		</div>
	);
}