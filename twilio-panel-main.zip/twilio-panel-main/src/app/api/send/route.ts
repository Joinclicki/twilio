import Twilio from "twilio";
import { ServiceListInstanceCreateOptions as NotifyService } from "twilio/lib/rest/notify/v1/service";

export async function POST(req: Request) {
  const {
    config,
    body,
    phoneNumbersTo,
    mediaUrl,
  }: {
    config: Config;
    body: string;
    phoneNumbersTo: string[];
    mediaUrl: string | undefined;
  } = await req.json();

  const client = Twilio(config.accountSid, config.authToken);

  const notifyProps = {
    friendlyName: "bulk_notify_service1",
    messagingServiceSid: config.messagingServiceSid,
  } as NotifyService;

  const notifyServices = await client.notify.v1.services.list();
  const notifyService = notifyServices.length
    ? await notifyServices[0].update(notifyProps)
    : await client.notify.v1.services.create(notifyProps);

  const promises = phoneNumbersTo.map(async (pn) => {
    await client.messages.create({
      from: config.messagingServiceSid,
      body,
      to: pn,
      mediaUrl: mediaUrl ? [mediaUrl] : undefined,
      sendAsMms: mediaUrl ? true : false,
    });
    return true;
  });

  await Promise.all(promises);
  // console.log({ notification });

  return Response.json({ status: "OK" });
}
