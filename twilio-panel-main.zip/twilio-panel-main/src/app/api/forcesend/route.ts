import Twilio from "twilio";

export async function POST(req: Request) {
	const { config, body, phoneNumberFrom, phoneNumberTo }: { config: Config; body: string; phoneNumberFrom: string; phoneNumberTo: string; } = await req.json();

	const client = Twilio(config.accountSid, config.authToken);

	await client.messages.create({
		messagingServiceSid: config.messagingServiceSid,
		from: phoneNumberFrom,
		to: phoneNumberTo,
		body,
	});

	return Response.json({ status: 'OK' });
}