import Twilio from "twilio";
import { MessageInstance } from "twilio/lib/rest/api/v2010/account/message";

export async function POST(req: Request) {
  const configs: Config[] = await req.json();
  const messagesMap = new Map<string, MessageInstance[]>();
  const deduplicate: string[] = [];

  for await (const config of configs) {
    if (deduplicate.includes(config.accountSid)) continue;
    deduplicate.push(config.accountSid);

    const client = Twilio(config.accountSid, config.authToken);
    const msgs = await client.messages.list({
      dateSentAfter: new Date(Date.now() - 86400000),
    }); // ? TODO each

    for await (const msg of msgs) {
      const key = [msg.to, msg.from].sort().join();

      if (!messagesMap.has(key)) messagesMap.set(key, []);
      messagesMap.get(key)!.unshift(msg);
    }
  }
  const messages = Array.from(messagesMap.values());
  /* messages.forEach((msgGroup) => {
		msgGroup.sort((a, b) => +a.dateSent - +b.dateSent);
	}); */

  return Response.json({ status: "OK", messages });
}
