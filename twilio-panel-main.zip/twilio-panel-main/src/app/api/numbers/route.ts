import Twilio from "twilio";
import { PhoneNumberInstance } from "twilio/lib/rest/messaging/v1/service/phoneNumber";

export async function POST(req: Request) {
	const config: Config = await req.json();
	// const { searchParams } = new URL(req.url);

	const client = Twilio(config.accountSid, config.authToken);

	const assignedPhoneNumbers: PhoneNumberInstance[] = [];

	const services = await client.messaging.v1.services.list();
	for await (const service of services) {
		const phoneNumbers = await service.phoneNumbers().list();
		assignedPhoneNumbers.push(...phoneNumbers);
	}

	const incomingPhoneNumbers = await client.incomingPhoneNumbers.list();

	const myPhoneNumbers = incomingPhoneNumbers.map((incomingPn) => ({
		sid: incomingPn.sid,
		friendlyName: incomingPn.friendlyName,
		phoneNumber: incomingPn.phoneNumber,
		messagingServiceSid: assignedPhoneNumbers.find((assignedPn) => incomingPn.sid === assignedPn.sid)?.serviceSid,
	} as PhoneNumber));

	return Response.json({ status: 'OK', myPhoneNumbers });
}