import Twilio from 'twilio';

export async function POST(req: Request) {
	/* const msg = Object.fromEntries(await req.formData());
	// console.log({ msg }); */

	const twiml = new Twilio.twiml.MessagingResponse;
	twiml.message('Message received, we will respond shortly. Reply STOP to unsubscribe.');

	return new Response(twiml.toString(), { headers: { 'Content-Type': 'text/xml' } });
}
