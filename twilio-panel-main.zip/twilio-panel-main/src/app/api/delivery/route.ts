import Pusher from 'pusher';

export async function POST(req: Request) {
	const deliveryData = Object.fromEntries(await req.formData());
	// console.log({ deliveryData });

	const pusher = new Pusher({
		appId: process.env.PUSHER_APP_ID,
		key: process.env.NEXT_PUBLIC_PUSHER_KEY,
		secret: process.env.PUSHER_SECRET,
		cluster: process.env.NEXT_PUBLIC_PUSHER_CLUSTER,
		useTLS: true,
	});

	await pusher.trigger('main_channel', 'message_delivery', {
		messageStatus: deliveryData.MessageStatus,
		from: deliveryData.From,
		to: deliveryData.To,
		errorCode: deliveryData.ErrorCode,
	} as MessageDelivery);

	return new Response('<Response/>', { headers: { 'Content-Type': 'text/xml' } });
}

/* 
MessagingServiceSid=MGb4b08df69a2148b7e5170a1938438e16
ApiVersion=2010-04-01
MessageStatus=delivered
RawDlrDoneDate=2402040403
SmsSid=SMd2877810d00e95440f4dbad6297dfd3f
SmsStatus=delivered
To=%2B18777804236
From=%2B12015819593
MessageSid=SMd2877810d00e95440f4dbad6297dfd3f
AccountSid=AC5321315720bd2b03f6e780cc033b6fd9
*/