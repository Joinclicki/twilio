import Twilio from "twilio";

// GET services
export async function POST(req: Request) {
	const config: Config = await req.json();

	const client = Twilio(config.accountSid, config.authToken);
	const msgServicesList = await client.messaging.v1.services.list();

	const messagingServices = msgServicesList.map((ms) => ({
		sid: ms.sid,
		friendlyName: ms.friendlyName,
		a2pRegistered: ms.usAppToPersonRegistered,
	} as MessagingService));

	return Response.json({ status: 'OK', messagingServices });
}

// add phone numbers to service
export async function PATCH(req: Request) {
	const { accountSid, authToken, messagingServiceSid, phoneNumbers }: { accountSid: string, authToken: string, messagingServiceSid: string; phoneNumbers: string[]; } = await req.json();

	const client = Twilio(accountSid, authToken);

	const responses: PhoneNumberResponse[] = [];

	await client.messaging.v1.services(messagingServiceSid).update({
		statusCallback: process.env.DELIVERY_STATUS_URL,
		inboundRequestUrl: process.env.RESPONSE_CALLBACK_URL,
	});

	for await (const phoneNumberSid of phoneNumbers) {
		const sender = await client.messaging.v1.services(messagingServiceSid).phoneNumbers.create({
			phoneNumberSid
		}).catch((err) => {
			responses.push({
				phoneNumberSid,
				error: err.toString(),
				helpUrl: err.moreInfo,
			});
		});

		if (sender) responses.push({ phoneNumberSid });
	}

	return Response.json({ status: 'OK', responses });
}