"use client";

import { useEffect, useRef, useState } from "react";
import { LOCAL_STORAGE_KEY } from "@/types/const";
import { MessageInstance } from "twilio/lib/rest/api/v2010/account/message";
import Loading from "@/app/loading";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import Reply from "./Reply";
import { InfoIcon } from "lucide-react";

export default function Messages() {
  const [messages, setMessages] = useState<MessageInstance[][]>([]);

  useEffect(() => {
    (async () => {
      const res = await fetch("/api/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: localStorage.getItem(LOCAL_STORAGE_KEY) || "[]",
      });
      const data = await res.json();
      /* data.messages.forEach((msgGroup: MessageInstance[]) => {
				msgGroup.sort((a, b) => +new Date(a.dateSent) - +new Date(b.dateSent)); // + converts to number
			}); */
      setMessages(data.messages);

      document
        .getElementById("bottom_0")
        ?.scrollIntoView({ behavior: "smooth" });
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <Tabs
        defaultValue="recipient_0"
        className="flex w-full"
        orientation="vertical"
      >
        <TabsList className="flex flex-col gap-2 pr-2 border-r min-w-fit overflow-auto">
          {messages.map((msgGroup, i) => (
            <TabsTrigger
              onClick={() =>
                document
                  .getElementById(`bottom_${i}`)
                  ?.scrollIntoView({ behavior: "smooth" })
              }
              key={`recipient_${i}`}
              value={`recipient_${i}`}
              className="bg-gray-200 data-[state=active]:bg-gray-400 p-2 rounded text-left"
            >
              <p>From: {msgGroup[0].from}</p>
              <p>To: {msgGroup[0].to}</p>
            </TabsTrigger>
          ))}
        </TabsList>

        {messages.length ? (
          messages.map((msgGroup, i) => {
            const configs: Config[] = JSON.parse(
              localStorage.getItem(LOCAL_STORAGE_KEY) || "[]"
            );

            const msg = msgGroup.find((mg) =>
              configs.find(
                (config) =>
                  config.messagingServiceSid === mg.messagingServiceSid &&
                  mg.direction.includes("outbound")
              )
            );

            return (
              <TabsContent
                key={`recipient_${i}`}
                value={`recipient_${i}`}
                className="outline-none overflow-auto w-full"
              >
                <div className="flex flex-col justify-between h-full mx-auto container">
                  <div className="p-2 flex flex-col gap-2">
                    {msgGroup.map((msg) => {
                      const outbound = msg.direction.includes("outbound");
                      const bgColor = {
                        accepted: "",
                        canceled: "bg-red-200",
                        delivered: "",
                        failed: "bg-red-200",
                        partially_delivered: "bg-red-200",
                        queued: "",
                        read: "",
                        received: "",
                        receiving: "",
                        scheduled: "",
                        sending: "",
                        sent: "",
                        undelivered: "bg-red-200",
                      }[msg.status];

                      return (
                        <div
                          className={cn(
                            "rounded-xl p-4 max-w-[80%] bg-[#e9e9eb] break-words",
                            outbound && "self-end bg-[#1186fe] text-white",
                            bgColor
                          )}
                          key={`msg_${msg.sid}`}
                          data-error={msg.errorCode}
                        >
                          <div className="flex items-center gap-2">
                            <b>{outbound ? `You (${msg.from})` : msg.from}</b> -{" "}
                            {new Date(msg.dateSent).toLocaleString()}
                            <TooltipProvider delayDuration={100}>
                              <Tooltip>
                                <TooltipTrigger>
                                  <InfoIcon className="h-[1.3em]" />
                                </TooltipTrigger>
                                <TooltipContent>
                                  {msg.status}
                                  {msg.numMedia === "0" ? (
                                    <div>NO MEDIA</div>
                                  ) : (
                                    <div>{msg.numMedia} Attached!</div>
                                  )}
                                  {msg.errorCode ? (
                                    <>
                                      {" "}
                                      (Error:{" "}
                                      <a
                                        className="Link"
                                        target="_blank"
                                        href={`https://www.twilio.com/docs/api/errors/${msg.errorCode}`}
                                      >
                                        {msg.errorCode}
                                      </a>
                                      )
                                    </>
                                  ) : (
                                    ""
                                  )}
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </div>
                          <p>{msg.body}</p>
                        </div>
                      );
                    })}
                    <div id={`bottom_${i}`} />
                  </div>

                  <div className="p-4 sticky bottom-0 bg-white">
                    <Reply
                      phoneNumberTo={msg?.to}
                      messagingServiceSid={msg?.messagingServiceSid}
                    />
                  </div>
                </div>
              </TabsContent>
            );
          })
        ) : (
          <Loading />
        )}
      </Tabs>
    </>
  );
}
