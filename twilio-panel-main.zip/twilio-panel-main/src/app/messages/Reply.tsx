"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";

import { Button } from "@/components/ui/button";
import {
	Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { toast } from "@/components/ui/use-toast";
import { LOCAL_STORAGE_KEY } from "@/types/const";

const FormSchema = z.object({
	body: z.string().min(1),
});

export default function Reply({ messagingServiceSid, phoneNumberTo }: { messagingServiceSid?: string; phoneNumberTo?: string; }) {
	const form = useForm<z.infer<typeof FormSchema>>({
		resolver: zodResolver(FormSchema),
		defaultValues: {
			body: '',
		},
	});

	async function onSubmit(data: z.infer<typeof FormSchema>) {
		const configs: Config[] = JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY) || '[]');
		const config = configs.find((config) => config.messagingServiceSid === messagingServiceSid);

		const res = await fetch('/api/send', {
			headers: {
				'Content-Type': 'application/json',
			},
			body: JSON.stringify({
				config: {
					accountSid: config?.accountSid,
					authToken: config?.authToken,
					messagingServiceSid: config?.messagingServiceSid,
				},
				body: data.body,
				phoneNumbersTo: [phoneNumberTo],
			}),
			method: 'POST',
		});

		form.reset({ body: '' });

		toast({
			title: res.ok ? "Sent." : "Failed!",
			/* description: (
				<pre className="mt-2 w-[340px] rounded-md bg-slate-950 p-4">
					<code className="text-white">{JSON.stringify(data, null, 2)}</code>
				</pre>
			), */
		});
	}

	return (
		<Form {...form}>
			<form onSubmit={form.handleSubmit(onSubmit)} className="flex gap-2">
				<FormField
					control={form.control}
					name="body"
					render={({ field }) => (
						<FormItem className="flex-1">
							<FormControl>
								<Input placeholder="Type a message" {...field} />
							</FormControl>
							<FormMessage />
						</FormItem>
					)}
				/>
				<Button disabled={!messagingServiceSid || !phoneNumberTo} type="submit">Send</Button>
			</form>
		</Form>
	);
}