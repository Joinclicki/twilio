import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";

import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/components/ui/use-toast";
import { LOCAL_STORAGE_KEY } from "@/types/const";
import { Dispatch, SetStateAction, useEffect, useState } from "react";
import { Checkbox } from "@/components/ui/checkbox";
import Loading from "@/app/loading";
import { InfoIcon } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

const FormSchema = z.object({
	id: z.string(),

	friendlyName: z.string(),
	accountSid: z.string().length(34),
	authToken: z.string().length(32),

	messagingServiceSid: z.string(),
	phoneNumbers: z.array(z.string())
}) satisfies z.ZodType<Config>;

export default function ConfigDialog({ children, id, configs, setConfigs }: Readonly<{ children: React.ReactNode; id?: string; configs: Config[]; setConfigs: Dispatch<SetStateAction<Config[]>>; }>) {
	const [formPage, setFormPage] = useState(0);

	const [messagingServices, setMessagingServices] = useState<MessagingService[]>([]);
	const [messagingServiceSid, setMessagingServiceSid] = useState('');

	const [phoneNumbers, setMyPhoneNumbers] = useState<PhoneNumber[]>([]);

	const i = configs.findIndex((config) => config.id === id);
	const config = configs[i];

	useEffect(() => {
		if (config) {
			setMessagingServiceSid(config.messagingServiceSid!);
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);


	const form = useForm<z.infer<typeof FormSchema>>({
		resolver: zodResolver(FormSchema),
		defaultValues: {
			id: id || '',

			friendlyName: config?.friendlyName || 'Main',
			accountSid: config?.accountSid || '',
			authToken: config?.authToken || '',

			messagingServiceSid: config?.messagingServiceSid || '',
			phoneNumbers: [],
		}
	});

	async function onSubmit(data: z.infer<typeof FormSchema>) {
		if (i < 0) {
			data.id = crypto.randomUUID();
			configs.push(data);
		}
		else configs[i] = data;

		localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(configs));
		setConfigs(configs);

		const res = await fetch('/api/services', {
			method: 'PATCH',
			headers: {
				'Content-Type': 'application/json',
			},
			body: JSON.stringify(data),
		});

		if (!res.ok) {
			toast({
				title: "Something went wrong!",
			});
		} else {
			const { responses }: { responses: PhoneNumberResponse[]; } = await res.json();

			toast({
				title: "Config saved.",
				description: (
					<div>
						<h2 className="text-md font-medium">Phone numbers added:</h2>
						{responses.map((res) => {
							const pn = phoneNumbers.find((pn) => pn.sid === res.phoneNumberSid);

							return (
								<div key={res.phoneNumberSid} className="flex items-center gap-2">
									<p className={!!res?.error ? 'text-red-400' : ''}>{pn?.friendlyName} ({pn?.phoneNumber})</p>
									{!!res?.error &&
										<TooltipProvider delayDuration={100}>
											<Tooltip>
												<TooltipTrigger>
													<InfoIcon className="h-[1.3em]" />
												</TooltipTrigger>
												<TooltipContent>
													{res?.error} (<a className="Link" target="_blank" href={res?.helpUrl}>Learn more</a>)
												</TooltipContent>
											</Tooltip>
										</TooltipProvider>
									}
								</div>
							);
						})}
					</div>
				),
			});

			form.reset();

			setFormPage(0);
			setMessagingServiceSid('');
			setMyPhoneNumbers([]);
		}
	}

	async function handleNext(accountSid: string, authToken: string) {
		setFormPage(formPage ? 0 : 1);

		const res = await fetch('/api/services', {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
			},
			body: JSON.stringify({
				accountSid,
				authToken,
			} as Config),
		});

		if (res.ok) {
			const data = await res.json();
			setMessagingServices(data.messagingServices);
		} else {
			toast({
				variant: 'destructive',
				title: 'Something went wrong!',
				description: 'Account SID or Auth Token may be wrong.'
			});
		}
	}

	async function handleServiceSelect(accountSid: string, authToken: string, messagingServiceSid: string) {
		setMessagingServiceSid(messagingServiceSid);

		const res = await fetch('/api/numbers', {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
			},
			body: JSON.stringify({
				accountSid,
				authToken,
			} as Config),
		});

		const { myPhoneNumbers }: { myPhoneNumbers: PhoneNumber[]; } = await res.json();

		form.resetField('phoneNumbers', {
			defaultValue: myPhoneNumbers.filter((pn) => pn.messagingServiceSid === messagingServiceSid).map((pn) => pn.sid)
		});

		setMyPhoneNumbers(myPhoneNumbers);
	}

	return (
		<Dialog>
			<DialogTrigger asChild>{children}</DialogTrigger>

			<DialogContent className="sm:max-w-[512px]">
				<DialogHeader>
					<DialogTitle>Edit config</DialogTitle>
					<DialogDescription>
						{formPage === 0
							? <>Enter your Account SID & Auth Token from the <a target="_blank" className="Link" href="https://console.twilio.com/">Twilio Console</a>.</>
							: <>Select or <a target="_blank" className="Link" href="https://www.twilio.com/console/sms/services">create</a> a Messaging Service.</>
						}
					</DialogDescription>
				</DialogHeader>
				<Form {...form}>
					<form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
						<div>
							<div className={formPage === 0 ? 'space-y-6' : 'hidden'}>
								<FormField
									control={form.control}
									name="friendlyName"
									render={({ field }) => (
										<FormItem>
											<FormLabel>Friendly name</FormLabel>
											<FormControl>
												<Input placeholder="Main" {...field} />
											</FormControl>
											<FormMessage />
										</FormItem>
									)}
								/>
								<FormField
									control={form.control}
									name="accountSid"
									render={({ field }) => (
										<FormItem>
											<FormLabel>Account SID</FormLabel>
											<FormControl>
												<Input placeholder="ACXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" {...field} />
											</FormControl>
											<FormMessage />
										</FormItem>
									)}
								/>
								<FormField
									control={form.control}
									name="authToken"
									render={({ field }) => (
										<FormItem>
											<FormLabel>Auth Token</FormLabel>
											<FormControl>
												<Input placeholder="XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" {...field} />
											</FormControl>
											<FormMessage />
										</FormItem>
									)}
								/>
							</div>
							<div className={formPage === 1 ? 'space-y-6' : 'hidden'}>
								<FormField
									control={form.control}
									name="messagingServiceSid"
									render={({ field }) => (
										<FormItem>
											<FormLabel>Messaging Service</FormLabel>
											<Select onValueChange={(value) => {
												field.onChange(value);
												handleServiceSelect(form.getValues().accountSid, form.getValues().authToken, value);
											}} defaultValue={field.value}>
												<FormControl>
													<SelectTrigger>
														<SelectValue placeholder="Select a Messaging Service" />
													</SelectTrigger>
												</FormControl>
												<SelectContent>
													{messagingServices.map((ms) =>
														<SelectItem key={ms.sid} value={ms.sid} >{ms.friendlyName} {ms.a2pRegistered ? <span className="text-green-600">(A2P Registered)</span> : ''}</SelectItem>
													)}
												</SelectContent>
											</Select>
											<FormMessage />
										</FormItem>
									)}
								/>
								{!!messagingServiceSid &&
									<FormField
										control={form.control}
										name="phoneNumbers"
										render={() => (
											<FormItem>
												<div className="mb-4">
													<FormLabel className="text-base">Phone numbers</FormLabel>
													<FormDescription>
														{!config &&
															<>Assign phone numbers to your Messaging Service.<br />Or </>
														}
														<>Manage SMS senders manually on the <a className="Link" href={`https://console.twilio.com/?frameUrl=${encodeURIComponent(`/console/sms/services/${messagingServiceSid}/senders`)}`} target="_blank">Twilio Console</a>.</>
													</FormDescription>
												</div>
												{!config && <>
													{!!phoneNumbers.length ?
														phoneNumbers.map((pn) => (
															<FormField
																key={pn.sid}
																control={form.control}
																name="phoneNumbers"
																render={({ field }) =>
																	<FormItem key={pn.sid} className="flex flex-row items-start space-x-3 space-y-0">
																		<FormControl>
																			<Checkbox
																				// ? TODO state manager
																				// defaultChecked={pn.messagingServiceSid === messagingServiceSid}
																				checked={field.value?.includes(pn.sid) ? true : undefined}
																				onCheckedChange={(checked) => checked
																					? field.onChange([...field.value, pn.sid])
																					: field.onChange(field.value?.filter((value) => value !== pn.sid))
																				}
																			/>
																		</FormControl>
																		<FormLabel className="font-normal">
																			{pn.friendlyName} ({pn.phoneNumber})
																		</FormLabel>
																	</FormItem>
																}
															/>
														)) : <div className="my-1"><Loading /></div>}
												</>}
												<FormMessage />
											</FormItem>
										)}
									/>
								}
							</div>
						</div>
						<DialogFooter>
							<Button type="button" onClick={() => handleNext(form.getValues().accountSid, form.getValues().authToken)}>{formPage === 0 ? 'Next' : 'Back'}</Button>
							<DialogClose asChild>
								<Button type="submit" disabled={formPage === 0}>Save changes</Button>
							</DialogClose>
						</DialogFooter>
					</form>
				</Form>
			</DialogContent>
		</Dialog>
	);
}