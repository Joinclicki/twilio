'use client';

import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { PlusIcon, Trash2Icon } from "lucide-react";
import { useEffect, useState, useCallback } from "react";
import ConfigDialog from "./ConfigDialog";
import { LOCAL_STORAGE_KEY } from "@/types/const";
import { toast } from "@/components/ui/use-toast";

export default function ConfigPage() {
	const [configs, setConfigs] = useState<Config[]>([]);

	const handleSetConfigs = useCallback(() => {
		setConfigs(JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY) || '[]'));
	}, []);

	useEffect(() => {
		handleSetConfigs();
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	function deleteConfig(id: string) {
		const newConfig = configs.filter((config) => config.id !== id);
		localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(newConfig));
		setConfigs(newConfig);
	}

	function clearConfigs() {
		localStorage.removeItem(LOCAL_STORAGE_KEY);
		setConfigs([]);

		toast({
			title: "Cleared all configs!"
		});
	}

	return (
		<div className="flex flex-col gap-2 w-full">
			<div className="flex gap-2">
				<ConfigDialog configs={configs} setConfigs={handleSetConfigs}>
					<Button className="w-32">
						<PlusIcon className="mr-2 h-4 w-4" /> Add new
					</Button>
				</ConfigDialog>
				<Button className="w-32" variant="destructive" onClick={() => clearConfigs()}>
					<Trash2Icon className="mr-2 h-4 w-4" /> Clear all
				</Button>
			</div>
			<Table className="w-full">
				<TableCaption>Configuration</TableCaption>
				<TableHeader>
					<TableRow>
						<TableHead className="">Friendly name</TableHead>
						<TableHead>Account SID</TableHead>
						<TableHead>Messaging Service</TableHead>
					</TableRow>
				</TableHeader>
				<TableBody>
					{configs.map((config, i) =>
						<TableRow key={`s_${config.id}`}>
							<TableCell>{config.friendlyName}</TableCell>
							<TableCell className="font-mono">{config.accountSid}</TableCell>
							<TableCell className="font-mono">{config.messagingServiceSid}</TableCell>
							<TableCell>
								<ConfigDialog id={config.id} configs={configs} setConfigs={handleSetConfigs}>
									<a className="Link">Edit</a>
								</ConfigDialog>
							</TableCell>
							<TableCell>
								<a className="cursor-pointer text-red-400" onClick={() => deleteConfig(config.id)}><Trash2Icon /></a>
							</TableCell>
						</TableRow>
					)}
				</TableBody>
			</Table>
		</div>
	);
}

