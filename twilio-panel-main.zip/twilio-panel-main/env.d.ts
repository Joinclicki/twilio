declare global {
	namespace NodeJS {
		interface ProcessEnv {
			PUSHER_APP_ID: string;
			PUSHER_SECRET: string;
			NEXT_PUBLIC_PUSHER_KEY: string;
			NEXT_PUBLIC_PUSHER_CLUSTER: string;

			DELIVERY_STATUS_URL: string;
			RESPONSE_CALLBACK_URL: string;
		}
	}
}

export { };